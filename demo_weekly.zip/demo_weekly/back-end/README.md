# back-end

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
nodemon index.js
```