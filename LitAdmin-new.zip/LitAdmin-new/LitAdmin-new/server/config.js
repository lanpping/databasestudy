/**
 * Created by jerry on 2017/7/6.
 */
var path = require('path');
module.exports = {
  publicPath: path.join(__dirname, 'public')
}